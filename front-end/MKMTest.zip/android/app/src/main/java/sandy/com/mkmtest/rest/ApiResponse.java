package sandy.com.mkmtest.rest;

/**
 * Created by Sandy Rizky on 26/08/2020.
 */
public class ApiResponse {
    String result;
    String name;
    String login_time;

    public String getResult() {
        return result;
    }

    public void setResult(String result) {
        this.result = result;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getLogin_time() {
        return login_time;
    }

    public void setLogin_time(String login_time) {
        this.login_time = login_time;
    }
}
