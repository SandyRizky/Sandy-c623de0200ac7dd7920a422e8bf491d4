package sandy.com.mkmtest.rest;

import retrofit2.Call;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.POST;

/**
 * Created by Sandy Rizky on 26/08/2020.
 */
public interface APIService {
    @FormUrlEncoded
    @POST("login.php")
    Call<ApiResponse> login(@Field("name") String username,
                            @Field("password") String password);

    @FormUrlEncoded
    @POST("register.php")
    Call<ApiResponse> register(@Field("name") String username,
                               @Field("password") String password);
}
