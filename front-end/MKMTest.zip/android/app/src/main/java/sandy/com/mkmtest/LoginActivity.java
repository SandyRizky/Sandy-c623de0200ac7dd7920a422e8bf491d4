package sandy.com.mkmtest;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import io.realm.Realm;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import sandy.com.mkmtest.realm.User;
import sandy.com.mkmtest.rest.APIClient;
import sandy.com.mkmtest.rest.APIService;
import sandy.com.mkmtest.rest.ApiResponse;

public class LoginActivity extends AppCompatActivity {
    private EditText inputUsername, inputPassword;
    private Button btnLogin, btnRegis;
    private Realm mRealm;
    APIService api;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        inputPassword = findViewById(R.id.inputPassLg);
        inputUsername = findViewById(R.id.inputNameLg);
        btnLogin = findViewById(R.id.btnLogin);
        btnRegis = findViewById(R.id.btnRegister);

        mRealm = Realm.getDefaultInstance();
        api = APIClient.getClient().create(APIService.class);

        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Login(inputUsername.getText().toString(), inputPassword.getText().toString());
            }
        });

        btnRegis.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
                Intent i = new Intent(getApplicationContext(), RegisterActivity.class);
                startActivity(i);
            }
        });
    }

    private void Login(String uname, String pass) {
        Call<ApiResponse> call = api.login(uname, pass);
        call.enqueue(new Callback<ApiResponse>() {
            @Override
            public void onResponse(Call<ApiResponse> call, Response<ApiResponse> response) {
                if (response.isSuccessful()) {
                    if (response.body().getResult().equals("OK")) {
                        mRealm.beginTransaction();
                        mRealm.delete(User.class);
                        mRealm.commitTransaction();

                        User newUser = new User();
                        newUser.setUsername(response.body().getName());
                        newUser.setLogin_time(response.body().getLogin_time());

                        mRealm.beginTransaction();
                        mRealm.copyToRealm(newUser);
                        mRealm.commitTransaction();

                        Toast.makeText(getBaseContext(), "login sukses", Toast.LENGTH_LONG).show();

                        finish();
                        Intent i = new Intent(getApplicationContext(), MainActivity.class);
                        startActivity(i);
                    } else {
                        Toast.makeText(getBaseContext(), "username/password salah", Toast.LENGTH_LONG).show();
                    }
                } else {
                    Toast.makeText(getBaseContext(), "gagal menghubungi server", Toast.LENGTH_LONG).show();
                }
            }

            @Override
            public void onFailure(Call<ApiResponse> call, Throwable t) {
                Toast.makeText(getBaseContext(), "Gagal menghubungi server", Toast.LENGTH_LONG).show();
            }
        });
    }
}
