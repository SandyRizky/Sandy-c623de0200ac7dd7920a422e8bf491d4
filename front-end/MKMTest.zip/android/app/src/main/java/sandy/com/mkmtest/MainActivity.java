package sandy.com.mkmtest;

import androidx.appcompat.app.AppCompatActivity;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.util.Date;

import io.realm.Realm;
import sandy.com.mkmtest.realm.User;

public class MainActivity extends AppCompatActivity {
    private Button btnHello;
    private Realm mRealm;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mRealm = Realm.getDefaultInstance();

        btnHello = findViewById(R.id.btnHello);

        btnHello.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                isUserLogedIn();
            }
        });
    }

    private void isUserLogedIn() {
        if(mRealm.where(User.class).count() > 0){
            final User user = mRealm.where(User.class).findFirst();
            Toast.makeText(this, "Hai, "+user.getUsername()+" waktu login anda "+user.getLogin_time(), Toast.LENGTH_LONG).show();
        }else{
            Intent i = new Intent(this, LoginActivity.class);
            startActivity(i);
        }
    }

}
