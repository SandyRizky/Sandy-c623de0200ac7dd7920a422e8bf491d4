package sandy.com.mkmtest.realm;

import io.realm.RealmObject;

/**
 * Created by Sandy Rizky on 26/08/2020.
 */
public class User extends RealmObject {
    String username;
    String login_time;

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getLogin_time() {
        return login_time;
    }

    public void setLogin_time(String login_time) {
        this.login_time = login_time;
    }
}
